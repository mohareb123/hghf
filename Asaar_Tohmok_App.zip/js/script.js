
function showSection(id) {
  document.querySelectorAll('.section').forEach(s => s.style.display = 'none');
  document.getElementById(id).style.display = 'block';
}

async function getDollarPrice() {
  const el = document.getElementById("dollar-price");
  el.innerText = "جاري التحميل...";
  try {
    const response = await fetch("https://api.exchangerate.host/latest?base=USD&symbols=EGP");
    const data = await response.json();
    el.innerText = `سعر الدولار الآن: ${data.rates.EGP.toFixed(2)} جنيه`;
  } catch (e) {
    el.innerText = "تعذر تحميل السعر!";
  }
}

async function getGoldPrice() {
  const el = document.getElementById("gold-price");
  el.innerText = "جاري التحميل...";
  try {
    const response = await fetch("https://api.exchangerate.host/latest?base=XAU&symbols=EGP");
    const data = await response.json();
    el.innerText = `سعر أوقية الذهب: ${data.rates.EGP.toFixed(2)} جنيه`;
  } catch (e) {
    el.innerText = "تعذر تحميل السعر!";
  }
}
